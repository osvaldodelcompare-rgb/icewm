#!/bin/sh
# Genera el submenú "Aplicaciones" de IceWM leyendo los archivos .desktop.
# Si existe icewm-menu-fdo lo usa; si no, usa el generador propio de abajo.
if command -v icewm-menu-fdo >/dev/null 2>&1; then
    exec icewm-menu-fdo --no-sep-others
fi

DIRS="/usr/share/applications /usr/local/share/applications $HOME/.local/share/applications"
for d in $(echo "${XDG_DATA_DIRS:-}" | tr ':' ' '); do DIRS="$DIRS $d/applications"; done

for d in $DIRS; do
    [ -d "$d" ] && find "$d" -maxdepth 2 -name '*.desktop' 2>/dev/null
done | sort -u | while IFS= read -r f; do
    awk -F= '
      /^\[/ { sec = ($0 == "[Desktop Entry]"); next }
      !sec { next }
      $1=="Name" && name=="" { name=substr($0,6) }
      $1=="Exec" && exec_=="" { exec_=substr($0,6) }
      $1=="Icon" && icon=="" { icon=substr($0,6) }
      $1=="Categories" { cats=substr($0,12) }
      $1=="NoDisplay" && $2=="true" { hide=1 }
      $1=="Hidden" && $2=="true" { hide=1 }
      $1=="Terminal" && $2=="true" { term=1 }
      END {
        if (hide || name=="" || exec_=="") exit
        gsub(/ %[a-zA-Z]/, "", exec_); gsub(/%[a-zA-Z]/, "", exec_)
        gsub(/"/, "", name)
        c = "Otros"
        if (cats ~ /Settings/) c = "Configuración"
        else if (cats ~ /Network|WebBrowser|Email/) c = "Internet"
        else if (cats ~ /Office/) c = "Oficina"
        else if (cats ~ /Graphics/) c = "Gráficos"
        else if (cats ~ /AudioVideo|Audio|Video/) c = "Multimedia"
        else if (cats ~ /Development/) c = "Desarrollo"
        else if (cats ~ /Game/) c = "Juegos"
        else if (cats ~ /System|Monitor|TerminalEmulator/) c = "Sistema"
        else if (cats ~ /Utility|Accessories/) c = "Accesorios"
        if (term) exec_ = "x-terminal-emulator -e " exec_
        if (icon=="") icon="-"
        printf "%s\t%s\t%s\t%s\n", c, name, icon, exec_
      }' "$f"
done | sort -t "$(printf '\t')" -k1,1 -k2,2f | awk -F'\t' '
  { if ($1 != cur) { if (cur != "") print "}"; cur = $1; print "menu \"" cur "\" folder {" }
    printf "  prog \"%s\" %s %s\n", $2, $3, $4 }
  END { if (cur != "") print "}" }'
