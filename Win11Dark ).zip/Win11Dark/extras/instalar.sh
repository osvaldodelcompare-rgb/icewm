#!/bin/sh
# Instala el tema Win11Dark y arma el menú de aplicaciones.
# Uso:  sh instalar.sh
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
TEMA="$(dirname "$AQUI")"
DEST="$HOME/.icewm"
mkdir -p "$DEST/themes"

# 1) Tema
if [ "$TEMA" != "$DEST/themes/Win11Dark" ]; then
    rm -rf "$DEST/themes/Win11Dark"
    cp -r "$TEMA" "$DEST/themes/Win11Dark"
fi
echo 'Theme="Win11Dark/default.theme"' > "$DEST/theme"

# 2) Menú (hace copia de seguridad del anterior)
[ -f "$DEST/menu" ] && cp "$DEST/menu" "$DEST/menu.bak.$(date +%s)"
cp "$AQUI/menu-apps.sh" "$DEST/menu-apps.sh"
chmod +x "$DEST/menu-apps.sh"
sed "s|@HOME@|$HOME|g" "$AQUI/menu" > "$DEST/menu"

echo "Listo. Reiniciá IceWM con:  icewm --restart"
echo "Si el menú sigue vacío, probá:  sh $DEST/menu-apps.sh | head"
