#!/bin/sh
# Instala el tema Win11Dark y arma el menú de aplicaciones.
# Uso:  sh instalar.sh
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
TEMA="$(dirname "$AQUI")"
DEST="$HOME/.icewm"
mkdir -p "$DEST/themes"

# 1) Tema
if [ "$TEMA" != "$DEST/themes/Win11Dark" ]; then
    rm -rf "$DEST/themes/Win11Dark"
    cp -r "$TEMA" "$DEST/themes/Win11Dark"
fi
echo 'Theme="Win11Dark/default.theme"' > "$DEST/theme"

# 2) Menú (hace copia de seguridad del anterior)
[ -f "$DEST/menu" ] && cp "$DEST/menu" "$DEST/menu.bak.$(date +%s)"
cp "$AQUI/menu-apps.sh" "$DEST/menu-apps.sh"
chmod +x "$DEST/menu-apps.sh"
sed "s|@HOME@|$HOME|g" "$AQUI/menu" > "$DEST/menu"
cp "$DEST/menu" "$DEST/menu-original"
cp "$AQUI/menu-icewm.sh" "$DEST/menu-icewm.sh"

# 3) Funciones extra, solo si usás el IceWM modificado (icewm-modificado/compilar.sh)
BIN="$(command -v icewm 2>/dev/null || true)"
if [ -n "$BIN" ] && grep -aq TaskBarCenterButtons "$BIN" 2>/dev/null; then
    echo "Detecté el IceWM modificado: activo esquinas redondeadas y barra centrada."
    grep -q '^CornerRadius=' "$DEST/themes/Win11Dark/default.theme" || \
        echo 'CornerRadius=10' >> "$DEST/themes/Win11Dark/default.theme"
    touch "$DEST/preferences"
    for l in TaskBarCenterButtons=1 TaskBarButtonMaxWidth=170 TaskBarShowWorkspaces=0 \
             TaskBarShowCPUStatus=0 TaskBarShowNetStatus=0 TaskBarShowMEMStatus=0; do
        k="${l%%=*}"
        grep -q "^$k=" "$DEST/preferences" || echo "$l" >> "$DEST/preferences"
    done
else
    echo "Estás usando el IceWM normal: el tema funciona, pero sin esquinas redondeadas ni barra centrada."
fi

echo "Listo. Reiniciá IceWM con:  icewm --restart"
echo "Si el menú sigue vacío, probá:  sh $DEST/menu-apps.sh | head"
