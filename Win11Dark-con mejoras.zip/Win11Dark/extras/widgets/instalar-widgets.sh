#!/bin/sh
# Instala el widget minimalista (Conky: CPU y RAM, translúcido) y lo inicia con IceWM.
# Uso:  sh instalar-widgets.sh
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"

echo "==> Programas necesarios: conky y picom"
if ! command -v conky >/dev/null 2>&1 || ! command -v picom >/dev/null 2>&1; then
    echo "Instalando conky-all y picom (pide la clave de sudo)..."
    sudo apt-get install -y conky-all picom
fi

echo "==> Copiando configuración"
mkdir -p "$HOME/.config/conky" "$HOME/.config/picom"
cp "$AQUI/win11.conf" "$HOME/.config/conky/win11.conf"
if [ -f "$HOME/.config/picom/picom.conf" ] && ! grep -q "Win11Dark" "$HOME/.config/picom/picom.conf"; then
    cp "$HOME/.config/picom/picom.conf" "$HOME/.config/picom/picom.conf.bak.$(date +%s)"
    echo "   (guardé tu picom.conf anterior como picom.conf.bak.*)"
fi
cp "$AQUI/picom.conf" "$HOME/.config/picom/picom.conf"

echo "==> Agregando al inicio de IceWM (~/.icewm/startup)"
mkdir -p "$HOME/.icewm"
START="$HOME/.icewm/startup"
[ -f "$START" ] || printf '#!/bin/sh\n' > "$START"
chmod +x "$START"
if ! grep -q ">>> win11dark-widgets" "$START"; then
    {
        echo ""
        echo "# >>> win11dark-widgets"
        # Si ya hay otro compositor corriendo, no se inicia picom
        echo 'pgrep -x "picom|compton|xcompmgr" >/dev/null || picom --config "$HOME/.config/picom/picom.conf" -b'
        echo 'sleep 1'
        echo 'pgrep -x conky >/dev/null || conky -c "$HOME/.config/conky/win11.conf" -d'
        echo "# <<< win11dark-widgets"
    } >> "$START"
fi

echo "==> Iniciando ahora"
if [ -n "$DISPLAY" ]; then
    pgrep -x picom >/dev/null || picom --config "$HOME/.config/picom/picom.conf" -b || true
    sleep 1
    pkill -x conky 2>/dev/null || true
    conky -c "$HOME/.config/conky/win11.conf" -d || true
fi
echo "Listo. Para cambiar posición o transparencia editá ~/.config/conky/win11.conf"
echo "Para quitarlo:  sh $AQUI/quitar-widgets.sh"
