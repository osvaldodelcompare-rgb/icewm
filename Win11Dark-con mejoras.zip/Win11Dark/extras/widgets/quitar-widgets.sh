#!/bin/sh
# Quita el widget del inicio de IceWM y lo cierra.
START="$HOME/.icewm/startup"
if [ -f "$START" ]; then
    cp "$START" "$START.bak.$(date +%s)"
    sed -i '/# >>> win11dark-widgets/,/# <<< win11dark-widgets/d' "$START"
fi
pkill -x conky 2>/dev/null
echo "Widget quitado (picom queda activo si lo iniciaste aparte; cerralo con: pkill picom)."
