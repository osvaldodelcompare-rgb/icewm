#!/bin/sh
# Instala el tema MacTahoe: tema, barra superior, menú de apps, picom (sombras/transparencia)
# y el dock Plank. Uso:  sh instalar-mac.sh
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
TEMA="$(dirname "$AQUI")"
UHOME="$HOME"
USUARIO=""

# Si corrés esto como root pero tu sesión de IceWM es de otro usuario, instalo en la carpeta de ESE usuario.
SESION="${ICEWM_USUARIO:-$(ps -o user= -C icewm 2>/dev/null | head -n1 | tr -d ' ')}"
if [ "$(id -u)" = 0 ] && [ -n "$SESION" ] && [ "$SESION" != root ]; then
    UHOME="$(getent passwd "$SESION" | cut -d: -f6)"
    USUARIO="$SESION"
    echo "Tu sesión de IceWM es del usuario '$SESION': instalo en $UHOME"
fi
DEST="$UHOME/.icewm"
mkdir -p "$DEST/themes" "$UHOME/.config/picom" "$UHOME/.local/share/plank/themes" "$UHOME/.config/plank/dock1/launchers"

echo "==> Programas necesarios (plank, picom, fuente Inter)"
if ! command -v plank >/dev/null 2>&1 || ! command -v picom >/dev/null 2>&1; then
    if [ "$(id -u)" = 0 ]; then SUDO=""; else SUDO="sudo"; fi
    $SUDO apt-get install -y plank picom
fi
fc-list 2>/dev/null | grep -qi "Inter" || { [ "$(id -u)" = 0 ] && apt-get install -y fonts-inter >/dev/null 2>&1 || true; }

echo "==> Tema"
if [ "$TEMA" != "$DEST/themes/MacTahoe" ]; then
    rm -rf "$DEST/themes/MacTahoe"
    cp -r "$TEMA" "$DEST/themes/MacTahoe"
fi
echo 'Theme="MacTahoe/default.theme"' > "$DEST/theme"

echo "==> Preferencias (barra arriba, reloj tipo macOS)"
touch "$DEST/preferences"
cp "$DEST/preferences" "$DEST/preferences.bak.$(date +%s)"
for l in 'TaskBarAtTop=1' 'TaskBarShowWorkspaces=0' 'TaskBarShowCPUStatus=0' 'TaskBarShowNetStatus=0' \
         'TaskBarShowMEMStatus=0' 'TimeFormat="%a %b %d  %H:%M"'; do
    k="${l%%=*}"
    if grep -q "^$k=" "$DEST/preferences"; then sed -i "s|^$k=.*|$l|" "$DEST/preferences"; else echo "$l" >> "$DEST/preferences"; fi
done

echo "==> Menú de aplicaciones"
[ -f "$DEST/menu" ] && cp "$DEST/menu" "$DEST/menu.bak.$(date +%s)"
cp "$AQUI/menu-apps.sh" "$DEST/menu-apps.sh"; chmod +x "$DEST/menu-apps.sh"
sed "s|@HOME@|$UHOME|g" "$AQUI/menu" > "$DEST/menu"
cp "$DEST/menu" "$DEST/menu-original"
cp "$AQUI/menu-icewm.sh" "$DEST/menu-icewm.sh"

echo "==> picom y dock"
[ -f "$UHOME/.config/picom/picom.conf" ] && ! grep -q "MacTahoe" "$UHOME/.config/picom/picom.conf" && \
    cp "$UHOME/.config/picom/picom.conf" "$UHOME/.config/picom/picom.conf.bak.$(date +%s)"
cp "$AQUI/picom-mac.conf" "$UHOME/.config/picom/picom.conf"
rm -rf "$UHOME/.local/share/plank/themes/MacTahoe"
cp -r "$AQUI/plank-tema" "$UHOME/.local/share/plank/themes/MacTahoe"
# Lanzadores del dock: solo los programas que existan en este equipo
for d in thunar pcmanfm firefox-esr firefox org.gnome.Terminal xfce4-terminal xterm mousepad libreoffice-startcenter; do
    f="/usr/share/applications/$d.desktop"
    [ -f "$f" ] && [ ! -f "$UHOME/.config/plank/dock1/launchers/$d.dockitem" ] && \
        printf '[PlankDockItemPreferences]\nLauncher=file://%s\n' "$f" > "$UHOME/.config/plank/dock1/launchers/$d.dockitem"
done

echo "==> Inicio automático (~/.icewm/startup)"
START="$DEST/startup"
[ -f "$START" ] || printf '#!/bin/sh\n' > "$START"
chmod +x "$START"
if ! grep -q ">>> mactahoe" "$START"; then
cat >> "$START" << 'EOS'

# >>> mactahoe
pgrep -x "picom|compton|xcompmgr" >/dev/null || picom --config "$HOME/.config/picom/picom.conf" -b
S='net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/'
if [ "$(gsettings get $S theme 2>/dev/null)" != "'MacTahoe'" ]; then
    gsettings set $S theme 'MacTahoe'
    gsettings set $S icon-size 52
    gsettings set $S zoom-enabled true
    gsettings set $S zoom-percent 150
fi
pgrep -x plank >/dev/null || (sleep 1; plank) &
# <<< mactahoe
EOS
fi

# IceWM modificado: esquinas redondeadas y menús redondeados ya vienen en el tema
BIN="$(command -v icewm 2>/dev/null || true)"
if [ -n "$BIN" ] && grep -aq TaskBarCenterButtons "$BIN" 2>/dev/null; then
    echo "IceWM modificado detectado: esquinas redondeadas activas."
else
    echo "Aviso: con el IceWM normal las ventanas tienen esquinas cuadradas (ver icewm-modificado/)."
fi

[ -n "$USUARIO" ] && chown -R "$USUARIO": "$DEST" "$UHOME/.config/picom" "$UHOME/.local/share/plank" "$UHOME/.config/plank"
echo "Listo. Reiniciá IceWM:  icewm --restart   (si el dock no aparece, cerrá sesión y volvé a entrar)"
echo "Quitar el dock/picom del inicio: borrá el bloque '>>> mactahoe' de $START"
