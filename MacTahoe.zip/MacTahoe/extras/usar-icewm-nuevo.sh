#!/bin/sh
# Hace que Debian use el IceWM modificado (/usr/local/bin/icewm) en lugar del original.
#
# Por qué hace falta: "icewm --restart" vuelve a lanzar el MISMO programa con el que
# arrancó la sesión (/usr/bin/icewm), aunque el nuevo esté instalado en /usr/local.
# Este script desvía /usr/bin/icewm hacia el nuevo (con dpkg-divert, así apt no lo pisa).
#
#   sh usar-icewm-nuevo.sh             activa el IceWM modificado y reinicia IceWM
#   sh usar-icewm-nuevo.sh deshacer    vuelve al IceWM original de Debian
# Hay que correrlo como root (en tu caso: ya estás en la terminal de root).
NUEVO=/usr/local/bin/icewm
SISTEMA="${ICEWM_SISTEMA:-/usr/bin/icewm}"

[ "$(id -u)" = 0 ] || { echo "Corré este script como root (su, o sudo sh $0)."; exit 1; }

if [ "$1" = "deshacer" ]; then
    [ -L "$SISTEMA" ] && rm -f "$SISTEMA"
    dpkg-divert --remove --rename "$SISTEMA"
    echo "Vuelve a usarse el IceWM original de Debian."
else
    [ -x "$NUEVO" ] || { echo "No encuentro $NUEVO. Corré antes icewm-modificado/compilar.sh"; exit 1; }
    if [ -L "$SISTEMA" ] && [ "$(readlink "$SISTEMA")" = "$NUEVO" ]; then
        echo "Ya estaba activado."
    else
        dpkg-divert --add --rename --divert "$SISTEMA.debian" "$SISTEMA" || exit 1
        ln -s "$NUEVO" "$SISTEMA"
        echo "Listo: $SISTEMA ahora apunta a $NUEVO (el original quedó en $SISTEMA.debian)."
    fi
fi

if [ -n "$DISPLAY" ] && [ -z "$ICEWM_SIN_REINICIO" ]; then
    echo "Reiniciando IceWM..."
    "$SISTEMA" --restart
else
    echo "Reiniciá IceWM:  icewm --restart"
fi
