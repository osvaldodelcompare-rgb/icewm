#!/bin/sh
# Administrador seguro del menú de inicio de IceWM.
# Cada cambio hace un respaldo automático, y siempre se puede deshacer.
#
#   sh menu-icewm.sh listar
#   sh menu-icewm.sh agregar "Nombre" comando [icono]
#   sh menu-icewm.sh quitar  "Nombre"
#   sh menu-icewm.sh deshacer        (vuelve al estado anterior al último cambio)
#   sh menu-icewm.sh respaldos       (lista los respaldos)
#   sh menu-icewm.sh original        (restaura el menú de MacTahoe)
#   sh menu-icewm.sh sistema         (usa el menú por defecto de Debian, con todas las apps)
MENU="$HOME/.icewm/menu"
RESP="$HOME/.icewm/menu-respaldos"
ORIG="$HOME/.icewm/menu-original"
mkdir -p "$RESP"

respaldar() { [ -f "$MENU" ] && cp "$MENU" "$RESP/menu.$(date +%Y%m%d-%H%M%S).$$"; return 0; }
aviso() { echo "Listo. Si no ves el cambio, reiniciá IceWM:  icewm --restart"; }

case "$1" in
listar)
    [ -f "$MENU" ] || { echo "No hay ~/.icewm/menu: IceWM usa el menú por defecto del sistema."; exit 0; }
    grep -nE '^[[:space:]]*(prog|menu|menuprog|menufile|includeprog|separator)' "$MENU"
    ;;
agregar)
    NOMBRE="$2"; CMD="$3"; ICONO="${4:--}"
    [ -n "$NOMBRE" ] && [ -n "$CMD" ] || { echo 'Uso: agregar "Nombre" comando [icono]'; exit 1; }
    case "$NOMBRE" in *\"*) echo "El nombre no puede tener comillas."; exit 1;; esac
    PRIMERA="${CMD%% *}"
    command -v "$PRIMERA" >/dev/null 2>&1 || \
        echo "Aviso: '$PRIMERA' no está instalado o no está en el PATH. IceWM OCULTA las entradas cuyo programa no existe."
    [ -f "$MENU" ] || touch "$MENU"
    respaldar
    LINEA="prog \"$NOMBRE\" $ICONO $CMD"
    if grep -q '^menuprog "Aplicaciones"' "$MENU"; then
        awk -v l="$LINEA" '/^menuprog "Aplicaciones"/ && !d { print l; d=1 } { print }' "$MENU" > "$MENU.tmp"
    else
        { cat "$MENU"; echo "$LINEA"; } > "$MENU.tmp"
    fi
    mv "$MENU.tmp" "$MENU"
    echo "Agregado: $NOMBRE"; aviso
    ;;
quitar)
    NOMBRE="$2"; [ -n "$NOMBRE" ] || { echo 'Uso: quitar "Nombre"'; exit 1; }
    [ -f "$MENU" ] || { echo "No hay ~/.icewm/menu."; exit 1; }
    grep -q "^prog \"$NOMBRE\" " "$MENU" || { echo "No encontré una entrada llamada '$NOMBRE'. Usá: listar"; exit 1; }
    respaldar
    awk -v n="prog \"$NOMBRE\" " 'index($0, n) != 1' "$MENU" > "$MENU.tmp" && mv "$MENU.tmp" "$MENU"
    echo "Quitado: $NOMBRE (se puede recuperar con: deshacer)"; aviso
    ;;
deshacer)
    ULT="$(ls -1 "$RESP"/menu.* 2>/dev/null | sort | tail -n 1)"
    [ -n "$ULT" ] || { echo "No hay respaldos para volver atrás."; exit 1; }
    [ -f "$MENU" ] && cp "$MENU" "$RESP/deshecho.$(date +%Y%m%d-%H%M%S).$$"
    cp "$ULT" "$MENU" && rm -f "$ULT"
    echo "Volví al estado anterior al último cambio."; aviso
    ;;
respaldos)
    ls -1 "$RESP" 2>/dev/null || echo "(sin respaldos)"
    echo "Los respaldos 'menu.*' sirven para 'deshacer'; los 'deshecho.*' son copias de lo que deshiciste."
    ;;
original)
    [ -f "$ORIG" ] || { echo "No encuentro $ORIG. Corré antes extras/instalar.sh del tema."; exit 1; }
    respaldar; cp "$ORIG" "$MENU"
    echo "Menú de MacTahoe restaurado."; aviso
    ;;
sistema)
    respaldar; rm -f "$MENU"
    echo "Ahora IceWM usa el menú por defecto de Debian (con todas tus aplicaciones instaladas)."; aviso
    ;;
*)
    sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'
    ;;
esac
