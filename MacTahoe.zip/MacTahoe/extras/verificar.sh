#!/bin/sh
# Diagnóstico: muestra qué IceWM está corriendo y si el tema tiene las opciones nuevas.
PID="$(pgrep -x icewm | head -n1)"
if [ -z "$PID" ]; then echo "IceWM no está corriendo en esta sesión."; exit 1; fi
USR="$(ps -o user= -p "$PID" | tr -d ' ')"
EXE="$(readlink -f /proc/$PID/exe 2>/dev/null)"
UHOME="$(getent passwd "$USR" | cut -d: -f6)"
echo "Usuario de la sesión de IceWM : $USR  (carpeta de configuración: $UHOME/.icewm)"
echo "Usuario de esta terminal      : $(id -un)  (HOME=$HOME)"
echo "Programa en ejecución         : ${EXE:-no se pudo leer (¿falta ser root?)}"
if [ -n "$EXE" ] && grep -aq TaskBarCenterButtons "$EXE" 2>/dev/null; then
    echo "  -> Es el IceWM MODIFICADO. Bien."
else
    echo "  -> Es el IceWM ORIGINAL de Debian: las esquinas redondeadas no pueden funcionar."
    echo "     Solución:  sh usar-icewm-nuevo.sh   (como root)"
fi
echo "'icewm' en el PATH             : $(command -v icewm)"
echo "Tema configurado              : $(cat "$UHOME/.icewm/theme" 2>/dev/null || echo '(ninguno en ~/.icewm/theme)')"
for t in "$UHOME/.icewm/themes/MacTahoe/default.theme" /usr/share/icewm/themes/MacTahoe/default.theme /usr/local/share/icewm/themes/MacTahoe/default.theme; do
    if [ -f "$t" ]; then
        if grep -q '^CornerRadius=' "$t"; then echo "  OK    $t (tiene CornerRadius)"
        else echo "  VIEJO $t (sin CornerRadius: reemplazalo por el del zip nuevo)"; fi
    fi
done
