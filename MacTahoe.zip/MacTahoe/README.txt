MacTahoe - tema claro para IceWM inspirado en macOS Tahoe

QUE INCLUYE
  - Tema de ventanas: botones circulares rojo/amarillo/verde a la izquierda (con simbolo al
    pasar el mouse), titulo centrado, esquinas redondeadas, fondo de pantalla propio (espacio, con nebulosa y planeta).
  - Barra de IceWM arriba (como la barra de menu), con reloj tipo "Fri Oct 30  04:59".
  - picom con sombras suaves; dock Plank translucido y redondeado, con zoom al pasar el mouse.
  - Administrador seguro del menu (extras/menu-icewm.sh) y el menu de aplicaciones.

INSTALACION (como el usuario de tu sesion; si sos root el instalador detecta al usuario)
  1) unzip MacTahoe.zip -d ~/.icewm/themes/
  2) sh ~/.icewm/themes/MacTahoe/extras/instalar-mac.sh
     (instala plank, picom y la fuente Inter con apt si faltan)
  3) Cerrar sesion y volver a entrar (o icewm --restart). El dock y picom arrancan solos
     desde ~/.icewm/startup (lo ejecuta icewm-session).

ESQUINAS REDONDEADAS: necesitan el IceWM modificado (carpeta icewm-modificado/):
  sh icewm-modificado/compilar.sh   y luego (root)   sh extras/usar-icewm-nuevo.sh
  Con el IceWM normal todo funciona, pero las ventanas tienen esquinas cuadradas.
  Para ver que IceWM corre:  sh extras/verificar.sh

AJUSTES
  - Radio de esquinas: CornerRadius=12 en default.theme (0 = cuadradas). Es un recorte sin
    suavizado; el borde se ve escalonado.
  - Dock: tamano y zoom con  gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ icon-size 48
  - Sombras: extras/picom-mac.conf (se copia a ~/.config/picom/picom.conf).
  - Quitar dock y picom del inicio: borrar el bloque ">>> mactahoe" de ~/.icewm/startup.

LIMITES (lo que NO se puede lograr con IceWM)
  - Vidrio con desenfoque/refraccion real, menu global (File/Edit/View) y la fuente de Apple.
  - Los iconos de las apps los pone el tema de iconos que uses (por ejemplo WhiteSur).

FONDOS
  - wallpaper.png (por defecto) = espacio. wallpaper-espacio.png es la misma imagen.
  - wallpaper-ola.png = la ola azul clara. Para usarla: DesktopBackgroundImage="wallpaper-ola.png"
    en default.theme (o una ruta tuya: DesktopBackgroundImage="/home/usuario/Imagenes/foto.jpg").
