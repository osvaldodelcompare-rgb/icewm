#!/bin/sh
# Compila IceWM 3.7.4 con las modificaciones de Win11Dark en Debian 13.
# Agrega: esquinas redondeadas (CornerRadius) y barra de tareas centrada
# (TaskBarCenterButtons). Se instala en /usr/local, sin tocar el IceWM de apt.
# Uso:  sh compilar.sh
set -e
# Si ya sos root (su), no hace falta sudo
if [ "$(id -u)" = 0 ]; then SUDO=""; else SUDO="sudo"; fi
VER=3.7.4
DIR="$(cd "$(dirname "$0")" && pwd)"
WORK="${HOME}/icewm-build"

echo "==> Instalando dependencias (pide la clave de sudo)..."
$SUDO apt-get update
$SUDO apt-get install -y build-essential cmake pkg-config gettext curl ca-certificates patch \
    libx11-dev libxft-dev libxext-dev libxrandr-dev libxinerama-dev libimlib2-dev \
    libfontconfig1-dev libxpm-dev libsm-dev libice-dev libxrender-dev libfribidi-dev \
    libglib2.0-dev libxcomposite-dev libxdamage-dev libxfixes-dev libxcursor-dev \
    libsndfile1-dev libasound2-dev

echo "==> Bajando el código fuente de IceWM $VER..."
mkdir -p "$WORK"
cd "$WORK"
curl -L -f -o "icewm-$VER.tar.gz" "https://github.com/ice-wm/icewm/archive/refs/tags/$VER.tar.gz"
rm -rf "icewm-$VER"
tar xzf "icewm-$VER.tar.gz"
cd "icewm-$VER"

echo "==> Aplicando las modificaciones..."
patch -p1 < "$DIR/icewm-win11.patch"

echo "==> Compilando (puede tardar unos minutos)..."
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local -DENABLE_LTO=OFF
cmake --build build -j"$(nproc)"

echo "==> Instalando en /usr/local..."
$SUDO cmake --install build

echo
echo "Listo, compilado e instalado en /usr/local/bin/icewm."
echo "IMPORTANTE: 'icewm --restart' sigue usando el IceWM viejo. Para activar el nuevo, como root:"
echo "    sh extras/usar-icewm-nuevo.sh      (está dentro de la carpeta del tema)"
